AJS.toInit(function ($) {
    $("#comments-actions").hide();
});
